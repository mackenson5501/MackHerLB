# MackHerLB

Application web de gestion pour MackHer Laverie & Blanchisserie. Interface en français et en créole haïtien, avec changement de langue.

## Fonctions de cette première version
- Connexion et création de compte par courriel/mot de passe.
- Tableau de bord.
- Gestion des clients.
- Gestion des commandes.
- Enregistrement des paiements.
- Gestion des rôles : propriétaire, admin, employé et client.
- Interface bilingue FR / Kreyòl.

## Configuration Firebase
Le projet est déjà préconfiguré avec les informations Web Firebase fournies par le propriétaire.
L'identifiant Firebase est public côté navigateur. Ne jamais ajouter une clé privée Firebase Admin SDK dans ce projet.

Dans Firebase Console :
1. Authentication > Sign-in method : activer Email/Password.
2. Firestore Database > Rules : publier le contenu de `firestore.rules`.
3. Authentication > Users : conserver le compte propriétaire avec l'UID indiqué dans `firestore.rules`.

Au premier login du propriétaire, l'application crée automatiquement son profil `users/{UID}` avec le rôle `proprietaire`.

## Exécuter localement
Installer Node.js, puis :
```bash
npm install
npm run dev
```

## Publier sur Netlify
1. Envoyer tous les fichiers de ce dossier dans le dépôt GitHub `mackenson5501/MackHerLB`.
2. Dans Netlify, importer ce dépôt.
3. Build command : `npm run build`
4. Publish directory : `dist`

Le fichier `netlify.toml` contient déjà ces paramètres.

## Important
Cette version est un point de départ fonctionnel, pas encore une solution de production complète. Les fonctions de création d'utilisateurs avec attribution de rôles, les permissions détaillées des employés, les sauvegardes, les tests et la validation des règles doivent être complétés avant d'utiliser des données réelles de clients ou de paiements. Ne partagez pas les mots de passe.