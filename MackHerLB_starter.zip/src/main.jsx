import React, { useEffect, useMemo, useState } from "react";
import { createRoot } from "react-dom/client";
import {
  initializeApp
} from "firebase/app";
import {
  getAuth, onAuthStateChanged, signInWithEmailAndPassword,
  createUserWithEmailAndPassword, signOut
} from "firebase/auth";
import {
  getFirestore, doc, getDoc, setDoc, collection, addDoc,
  getDocs, query, orderBy, serverTimestamp, updateDoc, deleteDoc
} from "firebase/firestore";
import {
  LayoutDashboard, Users, ClipboardList, CreditCard, LogOut,
  Languages, Plus, Search, Menu, X, Droplets, Settings, Trash2
} from "lucide-react";
import "./style.css";

const firebaseConfig = {
  apiKey: "AIzaSyDIZhWBhR_hOx50F35-w1aklVruDJhWOZc",
  authDomain: "mackherlb.firebaseapp.com",
  projectId: "mackherlb",
  storageBucket: "mackherlb.firebasestorage.app",
  messagingSenderId: "740758289998",
  appId: "1:740758289998:web:b9154fe7c115f65eb38d1f"
};
const fb = initializeApp(firebaseConfig);
const auth = getAuth(fb);
const db = getFirestore(fb);
const OWNER_UID = "KhZ5Kx3yjrhdtjiAOiqiNc2N1Oh1";

const words = {
  fr: {
    brand:"MackHer", subtitle:"Laverie & Blanchisserie", login:"Connexion", signup:"Créer un compte",
    email:"Adresse e-mail", password:"Mot de passe", enter:"Se connecter", create:"Créer mon compte",
    dashboard:"Tableau de bord", clients:"Clients", orders:"Commandes", payments:"Paiements",
    settings:"Paramètres", logout:"Déconnexion", welcome:"Bienvenue", revenue:"Revenus enregistrés",
    clientCount:"Clients", orderCount:"Commandes", pending:"En attente", newClient:"Nouveau client",
    newOrder:"Nouvelle commande", name:"Nom complet", phone:"Téléphone", address:"Adresse",
    service:"Service", amount:"Montant (HTG)", status:"Statut", date:"Date", save:"Enregistrer",
    cancel:"Annuler", search:"Rechercher", noData:"Aucune donnée pour le moment.",
    laundry:"Lavage", dry:"Nettoyage à sec", ironing:"Repassage", delivery:"Collecte & livraison",
    received:"Reçu", washing:"En cours", ready:"Prêt", delivered:"Livré",
    clientAdded:"Client ajouté.", orderAdded:"Commande créée.", paymentAdded:"Paiement enregistré.",
    access:"Votre compte n'a pas encore de rôle autorisé. Contactez le propriétaire.",
    role:"Rôle", client:"Client", employee:"Employé", admin:"Admin", owner:"Propriétaire",
    language:"Langue", amountPaid:"Montant payé", balance:"Solde", pay:"Enregistrer paiement",
    actions:"Actions", delete:"Supprimer", assigned:"Employé assigné", choose:"Choisir",
    error:"Une erreur est survenue. Vérifiez la connexion et les règles Firebase."
  },
  ht: {
    brand:"MackHer", subtitle:"Laveri & Blanchisri", login:"Konekte", signup:"Kreye kont",
    email:"Adrès imel", password:"Modpas", enter:"Konekte", create:"Kreye kont mwen",
    dashboard:"Tablo prensipal", clients:"Kliyan", orders:"Kòmand", payments:"Peman",
    settings:"Paramèt", logout:"Dekonekte", welcome:"Byenveni", revenue:"Lajan ki anrejistre",
    clientCount:"Kliyan", orderCount:"Kòmand", pending:"An atant", newClient:"Nouvo kliyan",
    newOrder:"Nouvo kòmand", name:"Non konplè", phone:"Telefòn", address:"Adrès",
    service:"Sèvis", amount:"Montan (HTG)", status:"Estati", date:"Dat", save:"Anrejistre",
    cancel:"Anile", search:"Chèche", noData:"Pa gen done pou kounye a.",
    laundry:"Lavaj", dry:"Netwayaj a sèk", ironing:"Repasaj", delivery:"Ranmase & livre",
    received:"Resevwa", washing:"Ap lave", ready:"Pare", delivered:"Livre",
    clientAdded:"Kliyan an anrejistre.", orderAdded:"Kòmand lan kreye.", paymentAdded:"Peman an anrejistre.",
    access:"Kont ou poko gen wòl ki otorize. Kontakte pwopriyetè a.",
    role:"Wòl", client:"Kliyan", employee:"Anplwaye", admin:"Admin", owner:"Pwopriyetè",
    language:"Lang", amountPaid:"Montan peye", balance:"Rès pou peye", pay:"Anrejistre peman",
    actions:"Aksyon", delete:"Efase", assigned:"Anplwaye ki responsab", choose:"Chwazi",
    error:"Gen yon erè. Verifye koneksyon an ak règ Firebase yo."
  }
};
function App() {
  const [lang,setLang] = useState(localStorage.getItem("mackher-lang") || "fr");
  const t = words[lang];
  const [user,setUser] = useState(null), [profile,setProfile] = useState(null), [page,setPage] = useState("dashboard");
  const [email,setEmail] = useState(""), [password,setPassword] = useState("");
  const [mode,setMode] = useState("login"), [busy,setBusy] = useState(false), [error,setError] = useState("");
  const [clients,setClients] = useState([]), [orders,setOrders] = useState([]), [payments,setPayments] = useState([]);
  const [clientForm,setClientForm] = useState({name:"",phone:"",address:""});
  const [orderForm,setOrderForm] = useState({clientUid:"",clientName:"",service:"Lavage",amount:"",status:"Reçu"});
  const [paymentForm,setPaymentForm] = useState({orderId:"",clientUid:"",amount:""});
  const [showForm,setShowForm] = useState(false), [searchText,setSearchText] = useState("");
  const owner = user?.uid === OWNER_UID || profile?.role === "proprietaire";
  const admin = owner || profile?.role === "admin";
  const employee = profile?.role === "employe";
  const tr = (s) => ({ "Lavage":t.laundry,"Nettoyage à sec":t.dry,"Repassage":t.ironing,"Collecte & livraison":t.delivery,
    "Reçu":t.received,"En cours":t.washing,"Prêt":t.ready,"Livré":t.delivered }[s] || s);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async u => {
      setUser(u); setProfile(null);
      if (!u) return;
      try {
        const ref = doc(db,"users",u.uid);
        let snap = await getDoc(ref);
        if (u.uid === OWNER_UID && !snap.exists()) {
          await setDoc(ref,{name:"Proprietaire MackHer",email:u.email || "",role:"proprietaire",active:true,createdAt:serverTimestamp()});
          snap = await getDoc(ref);
        }
        if (snap.exists()) setProfile(snap.data());
      } catch(e) { setError(e.message); }
    });
    return () => unsub();
  }, []);

  async function loadData() {
    if (!user || !profile) return;
    try {
      const [c,o,p] = await Promise.all([
        getDocs(query(collection(db,"clients"),orderBy("createdAt","desc"))),
        getDocs(query(collection(db,"orders"),orderBy("createdAt","desc"))),
        getDocs(query(collection(db,"payments"),orderBy("createdAt","desc")))
      ]);
      setClients(c.docs.map(d=>({id:d.id,...d.data()})));
      setOrders(o.docs.map(d=>({id:d.id,...d.data()})));
      setPayments(p.docs.map(d=>({id:d.id,...d.data()})));
    } catch(e) { setError(e.message); }
  }
  useEffect(()=>{ loadData(); },[user,profile]);
  async function submitAuth(e) {
    e.preventDefault(); setBusy(true); setError("");
    try {
      if(mode==="login") await signInWithEmailAndPassword(auth,email,password);
      else await createUserWithEmailAndPassword(auth,email,password);
    } catch(e) { setError(e.message); }
    finally { setBusy(false); }
  }
  async function addClient(e) {
    e.preventDefault(); setBusy(true);
    try {
      await addDoc(collection(db,"clients"),{...clientForm,createdAt:serverTimestamp()});
      setClientForm({name:"",phone:"",address:""}); setShowForm(false); await loadData();
    } catch(e) { setError(e.message); } finally { setBusy(false); }
  }
  async function addOrder(e) {
    e.preventDefault(); setBusy(true);
    try {
      await addDoc(collection(db,"orders"),{...orderForm,amount:Number(orderForm.amount),amountPaid:0,balance:Number(orderForm.amount),createdAt:serverTimestamp(),createdBy:user.uid});
      setOrderForm({clientUid:"",clientName:"",service:"Lavage",amount:"",status:"Reçu"}); setShowForm(false); await loadData();
    } catch(e) { setError(e.message); } finally { setBusy(false); }
  }
  async function addPayment(e) {
    e.preventDefault(); setBusy(true);
    try {
      const order = orders.find(o=>o.id===paymentForm.orderId);
      const amount = Number(paymentForm.amount);
      if(!order || amount<=0 || amount>Number(order.balance)) throw new Error("Montant de paiement invalide.");
      await addDoc(collection(db,"payments"),{orderId:order.id,clientUid:order.clientUid || "",amount,createdAt:serverTimestamp(),createdBy:user.uid});
      await updateDoc(doc(db,"orders",order.id),{amountPaid:Number(order.amountPaid||0)+amount,balance:Number(order.balance)-amount});
      setPaymentForm({orderId:"",clientUid:"",amount:""}); setShowForm(false); await loadData();
    } catch(e) { setError(e.message); } finally { setBusy(false); }
  }
  async function removeClient(id) {
    if(!confirm(lang==="fr"?"Supprimer ce client ?":"Efase kliyan sa a ?")) return;
    try { await deleteDoc(doc(db,"clients",id)); await loadData(); } catch(e) { setError(e.message); }
  }
  const totalRevenue = payments.reduce((s,p)=>s+Number(p.amount||0),0);
  const filteredClients = clients.filter(c=>(c.name||"").toLowerCase().includes(searchText.toLowerCase())||(c.phone||"").includes(searchText));
  if(!user) return <div className="auth-wrap"><div className="auth-card"><div className="logo"><Droplets size={28}/></div><h1>MackHer</h1><p>{t.subtitle}</p><div className="lang-row"><button onClick={()=>{setLang("fr");localStorage.setItem("mackher-lang","fr")}}>Français</button><button onClick={()=>{setLang("ht");localStorage.setItem("mackher-lang","ht")}}>Kreyòl</button></div><h2>{mode==="login"?t.login:t.signup}</h2><form onSubmit={submitAuth}><label>{t.email}<input type="email" required value={email} onChange={e=>setEmail(e.target.value)}/></label><label>{t.password}<input type="password" minLength="6" required value={password} onChange={e=>setPassword(e.target.value)}/></label><button className="primary" disabled={busy}>{busy?"...":mode==="login"?t.enter:t.create}</button></form><button className="link" onClick={()=>setMode(mode==="login"?"signup":"login")}>{mode==="login"?t.signup:t.login}</button>{error&&<p className="error">{error}</p>}</div></div>;
  if(!profile) return <div className="center"><div className="spinner"/><p>{error || t.access}</p><button onClick={()=>signOut(auth)}>{t.logout}</button></div>;
  const nav=[["dashboard",LayoutDashboard,t.dashboard],["clients",Users,t.clients],["orders",ClipboardList,t.orders],["payments",CreditCard,t.payments]];
  return <div className="app-shell">
    <aside className="sidebar"><div className="brand"><Droplets/><div><b>MackHer</b><small>{t.subtitle}</small></div></div>
      <nav>{nav.map(([id,Icon,label])=><button key={id} className={page===id?"active":""} onClick={()=>{setPage(id);setShowForm(false)}}><Icon size={18}/>{label}</button>)}</nav>
      {owner&&<div className="role-chip">{t.owner}</div>}
      <button className="logout" onClick={()=>signOut(auth)}><LogOut size={18}/>{t.logout}</button>
    </aside>
    <main className="main">
      <header><div><span className="eyebrow">MACKHER LAVERIE & BLANCHISSERIE</span><h1>{nav.find(n=>n[0]===page)?.[2] || t.dashboard}</h1></div>
        <div className="header-actions"><button className="language" onClick={()=>{const n=lang==="fr"?"ht":"fr";setLang(n);localStorage.setItem("mackher-lang",n)}}><Languages size={17}/>{lang==="fr"?"Kreyòl":"Français"}</button><button className="avatar" title={user.email}>{(user.email||"M").slice(0,1).toUpperCase()}</button></div>
      </header>
      {error&&<div className="notice">{error}</div>}
      {page==="dashboard"&&<><section className="welcome"><div><h2>{t.welcome}, {profile.name||user.email}</h2><p>{t.subtitle}</p></div><span>{new Date().toLocaleDateString(lang==="fr"?"fr-FR":"ht-HT")}</span></section><section className="stats">
        <div className="stat"><span>{t.revenue}</span><strong>{totalRevenue.toLocaleString()} HTG</strong></div>
        <div className="stat"><span>{t.clientCount}</span><strong>{clients.length}</strong></div>
        <div className="stat"><span>{t.orderCount}</span><strong>{orders.length}</strong></div>
        <div className="stat"><span>{t.pending}</span><strong>{orders.filter(o=>o.status!=="Livré").length}</strong></div>
      </section><section className="panel"><h3>{t.orders}</h3><OrdersTable orders={orders.slice(0,6)} t={t} tr={tr}/></section></>}
      {page==="clients"&&<section className="panel"><div className="panel-head"><h3>{t.clients}</h3>{admin&&<button className="primary small" onClick={()=>setShowForm(!showForm)}><Plus size={16}/>{t.newClient}</button>}</div>
        {showForm&&<form className="form-grid" onSubmit={addClient}><input required placeholder={t.name} value={clientForm.name} onChange={e=>setClientForm({...clientForm,name:e.target.value})}/><input placeholder={t.phone} value={clientForm.phone} onChange={e=>setClientForm({...clientForm,phone:e.target.value})}/><input placeholder={t.address} value={clientForm.address} onChange={e=>setClientForm({...clientForm,address:e.target.value})}/><button className="primary">{t.save}</button></form>}
        <div className="search"><Search size={17}/><input placeholder={t.search} value={searchText} onChange={e=>setSearchText(e.target.value)}/></div>
        <div className="table-wrap"><table><thead><tr><th>{t.name}</th><th>{t.phone}</th><th>{t.address}</th>{admin&&<th>{t.actions}</th>}</tr></thead><tbody>{filteredClients.map(c=><tr key={c.id}><td>{c.name}</td><td>{c.phone}</td><td>{c.address}</td>{admin&&<td><button className="icon-btn" onClick={()=>removeClient(c.id)}><Trash2 size={16}/></button></td>}</tr>)}</tbody></table>{!filteredClients.length&&<p className="empty">{t.noData}</p>}</div>
      </section>}
      {page==="orders"&&<section className="panel"><div className="panel-head"><h3>{t.orders}</h3><button className="primary small" onClick={()=>setShowForm(!showForm)}><Plus size={16}/>{t.newOrder}</button></div>
        {showForm&&<form className="form-grid" onSubmit={addOrder}><select required value={orderForm.clientUid} onChange={e=>{const c=clients.find(x=>x.id===e.target.value);setOrderForm({...orderForm,clientUid:e.target.value,clientName:c?.name||""})}}><option value="">{t.choose} {t.client}</option>{clients.map(c=><option value={c.id} key={c.id}>{c.name}</option>)}</select><select value={orderForm.service} onChange={e=>setOrderForm({...orderForm,service:e.target.value})}><option>Lavage</option><option>Nettoyage à sec</option><option>Repassage</option><option>Collecte & livraison</option></select><input required type="number" min="0" placeholder={t.amount} value={orderForm.amount} onChange={e=>setOrderForm({...orderForm,amount:e.target.value})}/><button className="primary">{t.save}</button></form>}
        <OrdersTable orders={orders} t={t} tr={tr}/>
      </section>}
      {page==="payments"&&<section className="panel"><div className="panel-head"><h3>{t.payments}</h3><button className="primary small" onClick={()=>setShowForm(!showForm)}><Plus size={16}/>{t.pay}</button></div>
        {showForm&&<form className="form-grid" onSubmit={addPayment}><select required value={paymentForm.orderId} onChange={e=>setPaymentForm({...paymentForm,orderId:e.target.value})}><option value="">{t.choose} {t.orders}</option>{orders.filter(o=>Number(o.balance)>0).map(o=><option key={o.id} value={o.id}>{o.clientName} · {o.balance} HTG</option>)}</select><input required type="number" min="1" placeholder={t.amount} value={paymentForm.amount} onChange={e=>setPaymentForm({...paymentForm,amount:e.target.value})}/><button className="primary">{t.save}</button></form>}
        <div className="table-wrap"><table><thead><tr><th>{t.date}</th><th>{t.orders}</th><th>{t.amount}</th></tr></thead><tbody>{payments.map(p=><tr key={p.id}><td>{p.createdAt?.toDate?.().toLocaleDateString()||"—"}</td><td>{p.orderId}</td><td>{p.amount} HTG</td></tr>)}</tbody></table>{!payments.length&&<p className="empty">{t.noData}</p>}</div>
      </section>}
      <footer>© {new Date().getFullYear()} MackHer · {t.subtitle}</footer>
    </main>
  </div>;
}
function OrdersTable({orders,t,tr}) {
  return <div className="table-wrap"><table><thead><tr><th>{t.client}</th><th>{t.service}</th><th>{t.amount}</th><th>{t.balance}</th><th>{t.status}</th></tr></thead><tbody>{orders.map(o=><tr key={o.id}><td>{o.clientName}</td><td>{tr(o.service)}</td><td>{o.amount} HTG</td><td>{o.balance} HTG</td><td><span className="status">{tr(o.status)}</span></td></tr>)}</tbody></table>{!orders.length&&<p className="empty">{t.noData}</p>}</div>;
}
createRoot(document.getElementById("root")).render(<App/>);